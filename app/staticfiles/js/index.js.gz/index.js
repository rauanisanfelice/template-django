function load_form(form){
    if (form.checkValidity()) {
        $("#cover").fadeIn(100);
    }
}

function load_page(){
    $("#cover").fadeIn(100);
}